/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulatorsederhana;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 *
 * @author admin
 */
public class FXMLDocumentController {
    
    @FXML
    TextField tfBilanganPertama;
    @FXML
    TextField tfBilanganKedua;
    @FXML
    Button btnTambah;
    @FXML
    Button btnKurang;
    @FXML
    Button btnKali;
    @FXML
    Button btnBagi;
    @FXML
    TextField tfHasil;
    
    @FXML
    private void onButtonClicked(ActionEvent event) {
        BilanganModel bilanganModel = new BilanganModel();
        
        //try catch untuk menghindari input selain angka
        try{
            bilanganModel.setBilanganPertama(Double.parseDouble(tfBilanganPertama.getText()));
            bilanganModel.setBilanganKedua(Double.parseDouble(tfBilanganKedua.getText()));
        } catch(NumberFormatException e1) {
            tfHasil.setText("Masukan hanya boleh angka");
            return;
        }
        
        if (event.getTarget().equals(btnTambah)){
            bilanganModel.setHasil(bilanganModel.getBilanganPertama() + bilanganModel.getBilanganKedua());
            tfHasil.setText(String.valueOf(bilanganModel.getHasil()));
        } else if (event.getTarget().equals(btnKurang)){
            bilanganModel.setHasil(bilanganModel.getBilanganPertama() - bilanganModel.getBilanganKedua());
            tfHasil.setText(String.valueOf(bilanganModel.getHasil()));
        } else if (event.getTarget().equals(btnKali)){
            bilanganModel.setHasil(bilanganModel.getBilanganPertama() * bilanganModel.getBilanganKedua());
            tfHasil.setText(String.valueOf(bilanganModel.getHasil()));
        } else if (event.getTarget().equals(btnBagi)){
            bilanganModel.setHasil(bilanganModel.getBilanganPertama() / bilanganModel.getBilanganKedua());
            tfHasil.setText(String.valueOf(bilanganModel.getHasil()));
        }
    }
}
