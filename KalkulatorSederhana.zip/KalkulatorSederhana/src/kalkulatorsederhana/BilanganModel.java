/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulatorsederhana;

/**
 *
 * @author admin
 */
public class BilanganModel {
    private double bilanganPertama;
    private double bilanganKedua;
    private double hasil;
    
    public double getBilanganPertama(){
        return bilanganPertama;
    }
    public void setBilanganPertama(double bilanganPertama){
        this.bilanganPertama=bilanganPertama;
    }
    public double getBilanganKedua(){
        return bilanganKedua;
    }
    public void setBilanganKedua(double bilanganKedua){
        this.bilanganKedua=bilanganKedua;
    }
    public double getHasil(){
        return hasil;
    }
    public void setHasil(double hasil){
        this.hasil=hasil;
    }  
}
